package com.codeinbars.ifridge;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView titleApp;
    private Typeface Sketch3D;
    private ListView foodList;
    private String fontSkecth = "fonts/Sketch3D.otf";
    private ArrayList<Food> foodListMain;
    private static String[] values;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        titleApp = findViewById(R.id.titleApp2);
        foodList = findViewById(R.id.foodList);
        this.Sketch3D = Typeface.createFromAsset(getAssets(),fontSkecth);
        titleApp.setTypeface(Sketch3D);
        MethodsFile.statusFile();
        foodListMain = MethodsFile.readFile();
        convertList(foodListMain, values);

        ArrayAdapter<String>adapter = new ArrayAdapter<String>(this,R.layout.listviewstyle, R.id.bText, values);
        foodList.setAdapter(adapter);

        foodList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int item = i;
                String itemval = (String) foodList.getItemAtPosition(i);
                Toast.makeText(getApplicationContext(), "Position: " + item + " Valor: " + itemval, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static void convertList(ArrayList<Food> list, String[] val){

        for(int i = 0; i<list.size(); i++){

            val[i] = list.get(i).getNombre();

        }
    }
}
