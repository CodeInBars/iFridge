package com.codeinbars.ifridge;

import java.util.Date;

public class Food {

    String nombre, fechaCompra, fechaCaducidad;

    public Food() {

    }

    public Food(String nombre, String fechaCompra, String fechaCaducidad) {
        this.nombre = nombre;
        this.fechaCompra = fechaCompra;
        this.fechaCaducidad = fechaCaducidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }
}
