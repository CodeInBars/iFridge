package com.codeinbars.ifridge;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;



public class MethodsFile {

    protected final static String fileName = "ifidgefood.txt";
    protected  static File fich = new File(fileName);

    public static void statusFile(){


        if(!fich.exists()){
            try{

                fich.createNewFile();

            }catch (IOException e){
                Log.e("ErrorCreateFile", "e: "+ e);
            }

        }

    }

    public static ArrayList<Food> readFile(){

        Food f;
        ArrayList<Food> listFood = new ArrayList<>();
        BufferedReader br;

        try {
            br = new BufferedReader(new FileReader(fich));
            String linea;

            while((linea=br.readLine())!=null){
                f = new Food();
                String[] campos = linea.split(";");
                f.setNombre(campos[0]);
                f.setFechaCompra(campos[1]);
                f.setFechaCaducidad(campos[2]);

                listFood.add(f);
            }
            br.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e){

        }

        return listFood;

    }

    public static void writeFile(Food f){

        try {
            BufferedWriter br = new BufferedWriter(new FileWriter(fich, true));
            String linea = "";
            linea += f.getNombre()+";";
            linea += f.getFechaCompra()+";";
            linea += f.getFechaCaducidad();
            br.write(linea);

        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
